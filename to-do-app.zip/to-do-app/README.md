# 📝 To-Do List App

A simple To-Do List web application built using HTML, CSS, and JavaScript.

## Features

- Add and remove tasks
- Tasks are saved in browser localStorage
- Responsive and clean UI

## How to Use

1. Open `index.html` in your browser
2. Type a task and click "Add Task"
3. Click ❌ to remove a task

## Screenshot

![screenshot](screenshot.png)

---

👨‍💻 Created by Santhosh